// console.log("Hello");

const api = {
    key: "63597c27a4e1ac35b81808be2c255c28",
    baseUrl: "https://api.openweathermap.org/data/2.5/weather",
    imageUrl : "http://openweathermap.org/img/w/"
}

const searchBox = document.getElementById('search');


searchBox.onkeypress = function (e) {
    if (!e) e = window.event;
    var keyCode = e.code || e.key;
    if (keyCode == 'Enter') {
        console.log(searchBox.value);
        getWeatherReport(searchBox.value);
        document.querySelector('.dynamicData').style.display = "block";
    }
}

// searchBox.addEventListener('keypress', (event) => {
//     // console.log(searchBox.value);
//     if (event.keycode == 13) {
//         console.log(searchBox.value);
//         getWeatherReport(searchBox.value);
//         document.querySelector('.dynamicData').style.display = "block";
//     }
// });

//Get weather report
function getWeatherReport(city){
    fetch(`${api.baseUrl}?q=${city}&appid=${api.key}&units=metric`)
    .then(weather => {
        return weather.json();
    }).then(showWeatherReport);
}

//Show Weather Report
function showWeatherReport(weather){
    console.log(weather);

    let city = document.getElementById('city');
    city.innerText = `${weather.name}, ${weather.sys.country}`;

    let temperature = document.getElementById('temperature');
    temperature.innerHTML = `${Math.round(weather.main.temp)}&deg;C`;
    let minMax = document.getElementById('min-max');
    minMax.innerHTML = `${Math.floor(weather.main.temp_min)}&deg;C (min) / ${Math.ceil(weather.main.temp_max)}&deg;C (max)`;

    let weatherType = document.getElementById('weather');
    weatherType.innerText = `${weather.weather[0].main}`;

    let date = document.getElementById('date');
    let todayDate = new Date();
    date.innerText = manageDate(todayDate);

    let sunrise = document.getElementById('sunrise');
    let sunset = document.getElementById('sunset');
    let unixSunrise = weather.sys.sunrise;
    let unixSunset = weather.sys.sunset;
    let dateSunrise = new Date(unixSunrise*1000);
    let dateSunset = new Date(unixSunset*1000);
    sunrise.innerText = `${dateSunrise.toLocaleTimeString()}`;
    sunset.innerText = `${dateSunset.toLocaleTimeString()}`;
    
    let wind = document.getElementById('wind');
    let pressure = document.getElementById('pressure');
    pressure.innerText = `${weather.main.pressure}hPa`;
    let degree = `${weather.wind.deg}`;
    if(degree>=11.25 || degree<33.75){
        wind.innerText = `${weather.wind.speed}m/s NNE`;
    }
    if(degree>=33.75 || degree<56.25){
        wind.innerText = `${weather.wind.speed}m/s NE`;
    }
    if(degree>=56.25 || degree<78.75){
        wind.innerText = `${weather.wind.speed}m/s ENE`;
    }
    if(degree>=78.75 || degree<101.25){
        wind.innerText = `${weather.wind.speed}m/s E`;
    }
    if(degree>=101.25 || degree<123.75){
        wind.innerText = `${weather.wind.speed}m/s ESE`;
    }
    if(degree>=123.75 || degree<146.25){
        wind.innerText = `${weather.wind.speed}m/s SE`;
    }
    if(degree>=146.25 || degree<168.75){
        wind.innerText = `${weather.wind.speed}m/s SSE`;
    }
    if(degree>=168.75 || degree<191.25){
        wind.innerText = `${weather.wind.speed}m/s S`;
    }
    if(degree>=191.25 || degree<213.75){
        wind.innerText = `${weather.wind.speed}m/s SSW`;
    }
    if(degree>=213.75 || degree<236.25){
        wind.innerText = `${weather.wind.speed}m/s SW`;
    }
    if(degree>=236.25 || degree<258.75){
        wind.innerText = `${weather.wind.speed}m/s WSW`;
    }
    if(degree>=258.75 || degree<281.25){
        wind.innerText = `${weather.wind.speed}m/s W`;
    }
    if(degree>=281.25 || degree<303.75){
        wind.innerText = `${weather.wind.speed}m/s WNW`;
    }
    if(degree>=303.75 || degree<326.25){
        wind.innerText = `${weather.wind.speed}m/s NW`;
    }
    if(degree>=326.25 || degree<348.75){
        wind.innerText = `${weather.wind.speed}m/s NNW`;
    }
    if(degree>=348.75 || degree<11.25){
        wind.innerText = `${weather.wind.speed}m/s N`;
    }
    // wind.innerText = `${weather.wind.speed}m/s`;

    let humidity = document.getElementById('humidity');
    humidity.innerText = `${weather.main.humidity}%`;
    
    let visibility = document.getElementById('visibility');
    let visible = parseFloat(weather.visibility);
    // console.log(visible);
    visibility.innerText = `Visibility: ${(visible/1000)} Km`;


    let icon = document.getElementById('iconImage');
    iconUrl = `${api.imageUrl}${weather.weather[0].icon}.png`;
    icon.src= iconUrl;
    // icon.innetHTML = `${weather.weather[0].icon}`;

    if(weatherType.textContent == 'Clear'){
        document.body.style.backgroundImage = "url('clear.jpg')";
    }

    else if(weatherType.textContent == 'Clouds'){
        document.body.style.backgroundImage = "url('clouds.jpg')";
    }

    else if(weatherType.textContent == 'Rain'){
        document.body.style.backgroundImage = "url('rain.jpg')";
    }

    else if(weatherType.textContent == 'Snow'){
        document.body.style.backgroundImage = "url('snow.jpg')";
    }

    else if(weatherType.textContent == 'ThunderStorm'){
        document.body.style.backgroundImage = "url('thunderstorm.jpg')";
    }

    else if(weatherType.textContent == 'Haze'){
        document.body.style.backgroundImage = "url('Haze.jpg')";
    }

    else if(weatherType.textContent == 'Smoke'){
        document.body.style.backgroundImage = "url('smoke.jpg')";
    }

    else if(weatherType.textContent == 'Mist'){
        document.body.style.backgroundImage = "url('mist.jpg')";
    }
    else if(weatherType.textContent == 'Fog'){
        document.body.style.backgroundImage = "url('fog.jpg')";
    }
}

//Manage Date
function manageDate(dateArg){
    let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    let year = dateArg.getFullYear();
    let month = months[dateArg.getMonth()];
    let date = dateArg.getDate();
    let day = days[dateArg.getDay()];

    return `${date} ${month} (${day}), ${year}`;
}