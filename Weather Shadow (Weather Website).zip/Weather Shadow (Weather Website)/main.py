from datetime import date
from flask import Flask, render_template, templating
import requests
from datetime import datetime
app = Flask(__name__)

@app.route("/")
def index():
    api = "63597c27a4e1ac35b81808be2c255c28"
    city = "Barabanki"
    link = "https://api.openweathermap.org/data/2.5/weather?q="+city+"&appid="+api
    api_request = requests.get(link)
    data = api_request.json()
    print(data)
    if data['cod'] == '404':
        pass
    else:
        date_time = datetime.now().strftime("%d %B %Y  |  %I:%M:%S:%p")
        temperature = int(((data['main']['temp'])-273.15))
        temp_min = int(((data['main']['temp_min'])-273.15))
        temp_max = int(((data['main']['temp_max'])-273.15))
        wind = data['wind']['speed']

        wind_degree = data['wind']['deg']
        if (wind_degree>=11.25 or wind_degree<33.75):
            direction = "m/s NNE"
        if(wind_degree>=33.75 or wind_degree<56.25):
            direction = "NE";
    
        if(wind_degree>=56.25 or wind_degree<78.75):
            direction = "m/s ENE";
    
        if(wind_degree>=78.75 or wind_degree<101.25):
            direction = "m/s E";
    
        if(wind_degree>=101.25 or wind_degree<123.75):
            direction = "m/s ESE";
    
        if(wind_degree>=123.75 or wind_degree<146.25):
            direction = "m/s SE";
    
        if(wind_degree>=146.25 or wind_degree<168.75):
            direction = "m/s SSE";
    
        if(wind_degree>=168.75 or wind_degree<191.25):
            direction = "m/s S";
    
        if(wind_degree>=191.25 or wind_degree<213.75):
            direction = "m/s SSW";
    
        if(wind_degree>=213.75 or wind_degree<236.25):
            direction = "m/s SW";
    
        if(wind_degree>=236.25 or wind_degree<258.75):
            direction = "m/s WSW";
    
        if(wind_degree>=258.75 or wind_degree<281.25):
            direction = "m/s W";
    
        if(wind_degree>=281.25 or wind_degree<303.75):
            direction = "m/s WNW";
    
        if(wind_degree>=303.75 or wind_degree<326.25):
            direction = "m/s NW";
    
        if(wind_degree>=326.25 or wind_degree<348.75):
            direction = "m/s NNW";
    
        if(wind_degree>=348.75 or wind_degree<11.25):
            direction = "m/s N";
    
    



        pressure = data['main']['pressure']
        humidity = data['main']['humidity']
        visibility = int((data['visibility'])/1000)
        # weather_type = data(['weather'].['main']

        #for testing purpose
        print(temperature )
        print(temp_min)
        print(temp_max)
        print(wind)
        print(pressure)
        print(humidity)
        print(visibility)
        print(date_time)
        print(wind_degree)
        # print(weather_type)

    return render_template('index.html',date_time=date_time, temperature=temperature, temp_min=temp_min, temp_max=temp_max, wind=wind, direction=direction, pressure=pressure, humidity=humidity, visibility=visibility)

app.run(debug=True)